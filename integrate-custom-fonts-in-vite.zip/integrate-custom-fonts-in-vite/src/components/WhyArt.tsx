"use client";

import { motion } from "framer-motion";

/**
 * Five calm line-art glyphs — one per reason in "What sets us apart".
 * Pure SVG, white on black, looping gently.
 */

const W = "rgba(255,255,255,";
const loop = { repeat: Infinity, ease: "easeInOut" as const };

/** 1 — No single solution for everyone: three different shapes, each with its own rhythm. */
function TailoredArt() {
  return (
    <>
      <motion.circle
        cx="60"
        cy="70"
        r="26"
        fill="none"
        stroke={`${W}0.7)`}
        strokeWidth="1.4"
        animate={{ scale: [1, 1.12, 1] }}
        transition={{ duration: 3.4, ...loop }}
        style={{ transformOrigin: "60px 70px" }}
      />
      <motion.rect
        x="94"
        y="44"
        width="52"
        height="52"
        rx="10"
        fill={`${W}0.08)`}
        stroke={`${W}0.6)`}
        strokeWidth="1.4"
        animate={{ rotate: [0, 90, 90, 0] }}
        transition={{ duration: 7, times: [0, 0.4, 0.6, 1], ...loop }}
        style={{ transformOrigin: "120px 70px" }}
      />
      <motion.path
        d="M180 44 L206 96 H154 Z"
        fill="#fff"
        animate={{ y: [0, -8, 0], opacity: [0.9, 1, 0.9] }}
        transition={{ duration: 4.2, ...loop }}
      />
      <line x1="30" y1="116" x2="210" y2="116" stroke={`${W}0.18)`} strokeWidth="1" strokeDasharray="2 6" />
    </>
  );
}

/** 2 — Design and technology together: two rings that lock into one shape. */
function UnionArt() {
  return (
    <>
      <motion.circle
        cx="100"
        cy="70"
        r="38"
        fill={`${W}0.05)`}
        stroke={`${W}0.7)`}
        strokeWidth="1.4"
        animate={{ x: [-14, 8, -14] }}
        transition={{ duration: 5, ...loop }}
      />
      <motion.circle
        cx="140"
        cy="70"
        r="38"
        fill={`${W}0.05)`}
        stroke={`${W}0.7)`}
        strokeWidth="1.4"
        animate={{ x: [14, -8, 14] }}
        transition={{ duration: 5, ...loop }}
      />
      <motion.ellipse
        cx="120"
        cy="70"
        rx="9"
        ry="26"
        fill="#fff"
        animate={{ scaleX: [0.5, 1.6, 0.5], opacity: [0.7, 1, 0.7] }}
        transition={{ duration: 5, ...loop }}
        style={{ transformOrigin: "120px 70px" }}
      />
    </>
  );
}

/** 3 — Thinking beyond the product: a core that keeps widening its frame. */
function BeyondArt() {
  return (
    <>
      <circle cx="120" cy="70" r="9" fill="#fff" />
      {[0, 1, 2].map((i) => (
        <motion.circle
          key={i}
          cx="120"
          cy="70"
          r="20"
          fill="none"
          stroke={`${W}0.5)`}
          strokeWidth="1.2"
          initial={{ scale: 1, opacity: 0.8 }}
          animate={{ scale: [1, 3.4], opacity: [0.8, 0] }}
          transition={{ duration: 4.2, delay: i * 1.4, repeat: Infinity, ease: "easeOut" }}
          style={{ transformOrigin: "120px 70px" }}
        />
      ))}
      <motion.g
        animate={{ rotate: 360 }}
        transition={{ duration: 16, repeat: Infinity, ease: "linear" }}
        style={{ transformOrigin: "120px 70px" }}
      >
        <circle cx="120" cy="70" r="46" fill="none" stroke={`${W}0.22)`} strokeDasharray="3 7" />
        <circle cx="166" cy="70" r="4.5" fill="#fff" />
      </motion.g>
    </>
  );
}

/** 4 — Details matter: a fine grid with one point being inspected. */
function DetailArt() {
  const dots: { x: number; y: number }[] = [];
  for (let r = 0; r < 5; r++) for (let c = 0; c < 9; c++) dots.push({ x: 40 + c * 20, y: 22 + r * 24 });
  return (
    <>
      {dots.map((d, i) => (
        <circle key={i} cx={d.x} cy={d.y} r="1.8" fill={`${W}0.3)`} />
      ))}
      <motion.g
        animate={{ x: [-40, 40, 40, -40], y: [-20, -20, 22, 22] }}
        transition={{ duration: 8, times: [0, 0.3, 0.7, 1], ...loop }}
      >
        <circle cx="120" cy="70" r="16" fill="none" stroke="#fff" strokeWidth="1.4" />
        <circle cx="120" cy="70" r="3.5" fill="#fff" />
        <line x1="120" y1="46" x2="120" y2="54" stroke={`${W}0.6)`} />
        <line x1="120" y1="86" x2="120" y2="94" stroke={`${W}0.6)`} />
        <line x1="96" y1="70" x2="104" y2="70" stroke={`${W}0.6)`} />
        <line x1="136" y1="70" x2="144" y2="70" stroke={`${W}0.6)`} />
      </motion.g>
    </>
  );
}

/** 5 — Building for what's next: bars that grow, and a dotted path that keeps going. */
function NextArt() {
  const heights = [26, 44, 64, 86];
  return (
    <>
      {heights.map((h, i) => (
        <motion.rect
          key={i}
          x={50 + i * 34}
          width="20"
          rx="4"
          fill={i === heights.length - 1 ? "#fff" : `${W}0.22)`}
          stroke={`${W}0.5)`}
          strokeWidth="1"
          initial={{ y: 120, height: 0 }}
          animate={{ y: [120, 120 - h, 120 - h, 120], height: [0, h, h, 0] }}
          transition={{ duration: 5.2, delay: i * 0.18, times: [0, 0.3, 0.85, 1], ...loop }}
        />
      ))}
      <motion.path
        d="M190 72 C 200 52, 212 40, 226 26"
        fill="none"
        stroke={`${W}0.7)`}
        strokeWidth="1.4"
        strokeDasharray="3 6"
        animate={{ strokeDashoffset: [0, -36] }}
        transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
      />
      <motion.circle
        cx="226"
        cy="26"
        r="4"
        fill="#fff"
        animate={{ scale: [0.7, 1.4, 0.7] }}
        transition={{ duration: 2.4, ...loop }}
        style={{ transformOrigin: "226px 26px" }}
      />
      <line x1="30" y1="120" x2="210" y2="120" stroke={`${W}0.25)`} strokeWidth="1" />
    </>
  );
}

const scenes = [TailoredArt, UnionArt, BeyondArt, DetailArt, NextArt];

export function WhyArt({ index, className }: { index: number; className?: string }) {
  const Scene = scenes[index % scenes.length];
  return (
    <svg viewBox="0 0 240 140" className={className} aria-hidden>
      <Scene />
    </svg>
  );
}
