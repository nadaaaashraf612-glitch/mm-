"use client";

import { memo, useEffect, useRef, useState, type ReactNode } from "react";
import { mountStage, type StageOpts } from "./kit";

/**
 * Hosts a glass WebGL scene. The canvas edges are feathered with a radial mask so the
 * studio backdrop melts into the surrounding page instead of reading as a box.
 */
function GlassCanvasBase({
  className,
  opts,
  fallback,
  feather = 62,
}: {
  className?: string;
  opts: StageOpts;
  fallback?: ReactNode;
  /** % radius where the feather starts */
  feather?: number;
}) {
  const hostRef = useRef<HTMLDivElement>(null);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    const host = hostRef.current;
    if (!host) return;
    const cleanup = mountStage(host, opts);
    if (!cleanup) {
      setFailed(true);
      return;
    }
    return cleanup;
    // opts is a module-level constant per scene
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const mask = `radial-gradient(closest-side, #000 ${feather}%, transparent 100%)`;

  return (
    <div className={className} aria-hidden>
      {failed ? (
        fallback
      ) : (
        <div
          ref={hostRef}
          className="absolute inset-0"
          style={{ WebkitMaskImage: mask, maskImage: mask }}
        />
      )}
    </div>
  );
}

export const GlassCanvas = memo(GlassCanvasBase);
