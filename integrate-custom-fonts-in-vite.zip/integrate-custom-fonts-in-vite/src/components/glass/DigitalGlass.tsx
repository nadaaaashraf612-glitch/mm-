"use client";

import { memo } from "react";
import * as THREE from "three";
import { RoundedBoxGeometry } from "three/addons/geometries/RoundedBoxGeometry.js";
import { GlassCanvas } from "./GlassCanvas";
import { glassMaterial, type StageOpts } from "./kit";
import { buildLogoGeometry } from "./logoGeometry";

/**
 * "Make it digital" — the whole PUIUX mark (cradle + dot) floats over a quiet field of glass
 * pixels. The dot rocks gently inside its cradle while a soft ripple passes through the pixels
 * beneath: analog → digital, kept deliberately calm.
 */
const N = 5;
const GAP = 0.5;

const opts: StageOpts = {
  tone: "light",
  frame: { w: 4.3, h: 4.1 },
  tilt: 0.5,
  introSeconds: 2,
  setup({ scene }) {
    const pixelGlass = glassMaterial({ smoke: 0x2e2e2e, distance: 1.0, thickness: 0.4, tint: 0x6e6e6e, envMapIntensity: 1.9 });
    const cradleGlass = glassMaterial({ smoke: 0x2e2e2e, distance: 1.1, thickness: 130, tint: 0x6e6e6e, envMapIntensity: 2.1 });
    const inkGlass = glassMaterial({ smoke: 0x181818, distance: 0.7, thickness: 140, tint: 0x4c4c4c, envMapIntensity: 2.3 });

    const group = new THREE.Group();
    group.position.y = -1.0;

    // ── the pixel field ───────────────────────────────────────────
    const cubeGeo = new RoundedBoxGeometry(0.36, 1, 0.36, 5, 0.07);
    const cubes: { mesh: THREE.Mesh; d: number }[] = [];
    const c = (N - 1) / 2;
    for (let i = 0; i < N; i++) {
      for (let j = 0; j < N; j++) {
        const mesh = new THREE.Mesh(cubeGeo, pixelGlass);
        mesh.position.set((i - c) * GAP, 0, (j - c) * GAP);
        group.add(mesh);
        cubes.push({ mesh, d: Math.hypot(i - c, j - c) });
      }
    }

    // ── the full mark: cradle + dot ───────────────────────────────
    const { body, dot, width } = buildLogoGeometry();
    const unit = 2.0 / width;
    const logo = new THREE.Group();
    logo.scale.setScalar(unit);
    const cradle = new THREE.Mesh(body, cradleGlass);
    const ball = new THREE.Mesh(dot, inkGlass);
    logo.add(cradle, ball);
    const logoRest = 1.35;
    logo.position.y = logoRest;
    group.add(logo);

    scene.add(group);

    return {
      update(t, cur, intro) {
        group.rotation.y = Math.sin(t * 0.45) * 0.38 + (1 - intro) * 1.2 + cur.x * 0.3;
        group.rotation.x = cur.y * 0.05;
        group.scale.setScalar(0.7 + 0.3 * intro);

        // the logo hovers; the dot rocks inside the cradle
        logo.position.y = logoRest + Math.sin(t * 1.1) * 0.05 + (1 - intro) * 0.8;
        ball.position.y = -Math.sin(t * 1.6) * 20;
        ball.position.x = Math.sin(t * 0.8) * 8;

        for (const { mesh, d } of cubes) {
          const wave = Math.max(0, Math.sin(d * 1.6 - t * 1.5));
          const h = 0.12 + wave * wave * 0.22 * intro;
          mesh.scale.y = h;
          mesh.position.y = h / 2;
        }
      },
      dispose() {
        cubeGeo.dispose();
        body.dispose();
        dot.dispose();
        pixelGlass.dispose();
        cradleGlass.dispose();
        inkGlass.dispose();
      },
    };
  },
};

function DigitalGlassBase({ className }: { className?: string }) {
  return <GlassCanvas className={className} opts={opts} feather={82} />;
}

export const DigitalGlass = memo(DigitalGlassBase);
