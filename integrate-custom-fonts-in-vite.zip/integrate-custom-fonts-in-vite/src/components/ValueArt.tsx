"use client";

import { motion } from "framer-motion";

/**
 * Five tiny, calm line-art scenes — one per company value. Pure SVG, white on black,
 * each looping gently so the card feels alive without ever being busy.
 */

const W = "rgba(255,255,255,";
const loop = { repeat: Infinity, ease: "easeInOut" as const };

/** Precision — a target that keeps finding its centre. */
function PrecisionArt() {
  return (
    <>
      {[22, 42, 62].map((r, i) => (
        <motion.circle
          key={r}
          cx="120"
          cy="70"
          r={r}
          fill="none"
          stroke={`${W}${0.28 - i * 0.06})`}
          strokeWidth="1"
          animate={{ scale: [1, 1.05, 1], opacity: [0.7, 1, 0.7] }}
          transition={{ duration: 3.2, delay: i * 0.25, ...loop }}
          style={{ transformOrigin: "120px 70px" }}
        />
      ))}
      <motion.circle
        cx="120"
        cy="70"
        r="52"
        fill="none"
        stroke={`${W}0.5)`}
        strokeWidth="1"
        strokeDasharray="3 7"
        animate={{ rotate: 360 }}
        transition={{ duration: 18, repeat: Infinity, ease: "linear" }}
        style={{ transformOrigin: "120px 70px" }}
      />
      <motion.g
        animate={{ x: [-34, 0, 0, -34], y: [18, 0, 0, 18] }}
        transition={{ duration: 4.5, times: [0, 0.45, 0.8, 1], ...loop }}
      >
        <line x1="120" y1="2" x2="120" y2="138" stroke={`${W}0.35)`} strokeWidth="1" />
        <line x1="40" y1="70" x2="200" y2="70" stroke={`${W}0.35)`} strokeWidth="1" />
      </motion.g>
      <motion.circle
        cx="120"
        cy="70"
        r="5"
        fill="#fff"
        animate={{ scale: [1, 1.5, 1] }}
        transition={{ duration: 2.2, ...loop }}
        style={{ transformOrigin: "120px 70px" }}
      />
    </>
  );
}

/** Uniqueness — one shape that refuses to match the grid. */
function UniquenessArt() {
  const dots: { x: number; y: number }[] = [];
  for (let r = 0; r < 4; r++) for (let c = 0; c < 7; c++) dots.push({ x: 48 + c * 24, y: 28 + r * 28 });
  return (
    <>
      {dots.map((d, i) => {
        const hero = d.x === 120 && d.y === 56;
        if (hero) return null;
        return (
          <motion.circle
            key={i}
            cx={d.x}
            cy={d.y}
            r="3"
            fill={`${W}0.3)`}
            animate={{ opacity: [0.35, 0.9, 0.35] }}
            transition={{ duration: 3, delay: (i % 7) * 0.18, ...loop }}
          />
        );
      })}
      <motion.circle
        cx="120"
        cy="56"
        r="12"
        fill="none"
        stroke={`${W}0.6)`}
        strokeWidth="1"
        initial={{ scale: 1, opacity: 0.8 }}
        animate={{ scale: [1, 2.6], opacity: [0.8, 0] }}
        transition={{ duration: 2.4, repeat: Infinity, ease: "easeOut" }}
        style={{ transformOrigin: "120px 56px" }}
      />
      <motion.rect
        x="108"
        y="44"
        width="24"
        height="24"
        rx="6"
        fill="#fff"
        animate={{ rotate: [45, 135, 45], scale: [1, 1.12, 1] }}
        transition={{ duration: 6, ...loop }}
        style={{ transformOrigin: "120px 56px" }}
      />
    </>
  );
}

/** Collaboration — three circles drifting into one shared centre. */
function CollaborationArt() {
  const circles = [
    { x: 100, y: 62, dx: 12, dy: 6 },
    { x: 140, y: 62, dx: -12, dy: 6 },
    { x: 120, y: 90, dx: 0, dy: -12 },
  ];
  return (
    <>
      {circles.map((c, i) => (
        <motion.circle
          key={i}
          cx={c.x}
          cy={c.y}
          r="30"
          fill={`${W}0.06)`}
          stroke={`${W}0.55)`}
          strokeWidth="1"
          animate={{ x: [-c.dx, c.dx, -c.dx], y: [-c.dy, c.dy, -c.dy] }}
          transition={{ duration: 5, delay: i * 0.2, ...loop }}
        />
      ))}
      <motion.circle
        cx="120"
        cy="72"
        r="5"
        fill="#fff"
        animate={{ scale: [0.7, 1.5, 0.7], opacity: [0.7, 1, 0.7] }}
        transition={{ duration: 2.5, ...loop }}
        style={{ transformOrigin: "120px 72px" }}
      />
    </>
  );
}

/** Continuous innovation — a staircase that is always one step further up. */
function InnovationArt() {
  const steps = "M40 116 H72 V92 H104 V68 H136 V44 H168 V20 H200";
  return (
    <>
      <path d={steps} fill="none" stroke={`${W}0.14)`} strokeWidth="1.5" strokeLinejoin="round" />
      <motion.path
        d={steps}
        fill="none"
        stroke="#fff"
        strokeWidth="1.8"
        strokeLinejoin="round"
        strokeLinecap="round"
        animate={{ pathLength: [0, 1, 1], opacity: [1, 1, 0] }}
        transition={{ duration: 4.2, times: [0, 0.75, 1], repeat: Infinity, ease: "easeInOut" }}
      />
      {[72, 104, 136, 168].map((x, i) => (
        <motion.circle
          key={x}
          cx={x}
          cy={116 - (i + 1) * 24}
          r="3.5"
          fill="#fff"
          animate={{ opacity: [0, 1, 1, 0], scale: [0.4, 1, 1, 0.4] }}
          transition={{ duration: 4.2, times: [(i + 1) * 0.15, (i + 1) * 0.15 + 0.08, 0.85, 1], repeat: Infinity }}
          style={{ transformOrigin: `${x}px ${116 - (i + 1) * 24}px` }}
        />
      ))}
      <motion.g
        animate={{ rotate: 360 }}
        transition={{ duration: 9, repeat: Infinity, ease: "linear" }}
        style={{ transformOrigin: "200px 20px" }}
      >
        <circle cx="200" cy="20" r="9" fill="none" stroke={`${W}0.5)`} strokeWidth="1" strokeDasharray="4 5" />
      </motion.g>
      <circle cx="200" cy="20" r="3.5" fill="#fff" />
    </>
  );
}

/** Ownership — a shield that is drawn, signed off, and held. */
function OwnershipArt() {
  const shield = "M120 18 L168 34 V72 C168 100 148 120 120 130 C92 120 72 100 72 72 V34 Z";
  return (
    <>
      <motion.circle
        cx="120"
        cy="74"
        r="46"
        fill="none"
        stroke={`${W}0.35)`}
        strokeWidth="1"
        animate={{ scale: [0.85, 1.35], opacity: [0.6, 0] }}
        transition={{ duration: 3, repeat: Infinity, ease: "easeOut" }}
        style={{ transformOrigin: "120px 74px" }}
      />
      <path d={shield} fill={`${W}0.05)`} stroke={`${W}0.18)`} strokeWidth="1.5" strokeLinejoin="round" />
      <motion.path
        d={shield}
        fill="none"
        stroke="#fff"
        strokeWidth="1.8"
        strokeLinejoin="round"
        animate={{ pathLength: [0, 1, 1, 1], opacity: [1, 1, 1, 0.35] }}
        transition={{ duration: 4.5, times: [0, 0.45, 0.85, 1], repeat: Infinity, ease: "easeInOut" }}
      />
      <motion.path
        d="M101 74 L115 88 L141 60"
        fill="none"
        stroke="#fff"
        strokeWidth="3"
        strokeLinecap="round"
        strokeLinejoin="round"
        animate={{ pathLength: [0, 0, 1, 1, 0] }}
        transition={{ duration: 4.5, times: [0, 0.4, 0.62, 0.9, 1], repeat: Infinity, ease: "easeInOut" }}
      />
    </>
  );
}

const scenes = [PrecisionArt, UniquenessArt, CollaborationArt, InnovationArt, OwnershipArt];

export function ValueArt({ index, className }: { index: number; className?: string }) {
  const Scene = scenes[index % scenes.length];
  return (
    <svg viewBox="0 0 240 140" className={className} aria-hidden>
      <Scene />
    </svg>
  );
}
