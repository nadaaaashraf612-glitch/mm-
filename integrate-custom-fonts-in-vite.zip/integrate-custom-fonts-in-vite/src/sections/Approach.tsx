"use client";

import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { BlurShapes } from "../components/BlurShapes";
import { Reveal } from "../components/Reveal";
import { Kicker, PageMeta } from "../components/ui";
import { useLanguage } from "../i18n/LanguageContext";

const DURATION = 5200;

/** Five principles arranged around a single point — the dot of the mark — and cycled as a story. */
function PrincipleOrbit({ count, active, onPick }: { count: number; active: number; onPick: (i: number) => void }) {
  const C = 210;
  const R = 150;
  const INNER = 62;
  const pts = Array.from({ length: count }, (_, i) => {
    const a = -Math.PI / 2 + (i * 2 * Math.PI) / count;
    return { x: C + Math.cos(a) * R, y: C + Math.sin(a) * R };
  });
  const poly = pts.map((p) => `${p.x},${p.y}`).join(" ");
  // point on the inner ring that faces a given node
  const edge = (p: { x: number; y: number }) => {
    const dx = p.x - C;
    const dy = p.y - C;
    const d = Math.hypot(dx, dy) || 1;
    return { x: C + (dx / d) * INNER, y: C + (dy / d) * INNER };
  };

  return (
    <div className="relative mx-auto aspect-square w-full max-w-[520px]">
      {/* glass disc */}
      <div className="absolute inset-0 rounded-full border border-white/10 bg-gradient-to-br from-white/[0.08] to-white/[0.01] shadow-[inset_0_0_80px_rgba(255,255,255,0.04),0_40px_100px_-40px_rgba(255,255,255,0.15)] backdrop-blur-xl" />
      <motion.div
        aria-hidden
        className="absolute inset-[6%] rounded-full border border-dashed border-white/15"
        animate={{ rotate: 360 }}
        transition={{ duration: 70, repeat: Infinity, ease: "linear" }}
      />

      <svg viewBox="0 0 420 420" className="relative h-full w-full" style={{ overflow: "visible" }}>
        <polygon points={poly} fill="none" stroke="rgba(255,255,255,0.14)" strokeWidth="1" />
        {pts.map((p, i) => {
          const e = edge(p);
          return <line key={i} x1={p.x} y1={p.y} x2={e.x} y2={e.y} stroke="rgba(255,255,255,0.06)" strokeWidth="1" />;
        })}

        {/* number ring — the number lives inside it, so nothing ever overlaps or clips it */}
        <circle cx={C} cy={C} r={INNER} fill="rgba(0,0,0,0.55)" stroke="rgba(255,255,255,0.22)" strokeWidth="1" />
        <motion.circle
          cx={C}
          cy={C}
          r={INNER + 9}
          fill="none"
          stroke="rgba(255,255,255,0.18)"
          strokeWidth="1"
          strokeDasharray="2 6"
          animate={{ rotate: 360 }}
          transition={{ duration: 40, repeat: Infinity, ease: "linear" }}
          style={{ transformOrigin: `${C}px ${C}px` }}
        />

        {/* active spoke draws toward the ring */}
        <AnimatePresence>
          <motion.line
            key={active}
            x1={pts[active].x}
            y1={pts[active].y}
            x2={edge(pts[active]).x}
            y2={edge(pts[active]).y}
            stroke="#fff"
            strokeWidth="1.5"
            initial={{ pathLength: 0, opacity: 0 }}
            animate={{ pathLength: 1, opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.9, ease: [0.16, 1, 0.3, 1] }}
          />
        </AnimatePresence>

        {/* big number — fully inside the viewBox, animated via a wrapper group (opacity + slide) */}
        <AnimatePresence mode="wait">
          <motion.g
            key={active}
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -14 }}
            transition={{ duration: 0.55, ease: [0.16, 1, 0.3, 1] }}
          >
            <text
              x={C}
              y={C}
              textAnchor="middle"
              dominantBaseline="central"
              className="font-display"
              fontSize="68"
              fontWeight="500"
              fill="#fff"
              style={{ fontVariantNumeric: "lining-nums" }}
            >
              {String(active + 1).padStart(2, "0")}
            </text>
          </motion.g>
        </AnimatePresence>

        {pts.map((p, i) => {
          const on = i === active;
          return (
            <g key={i} onClick={() => onPick(i)} style={{ cursor: "pointer" }}>
              {on && (
                <motion.circle
                  cx={p.x}
                  cy={p.y}
                  r="22"
                  fill="none"
                  stroke="rgba(255,255,255,0.6)"
                  initial={{ r: 18, opacity: 0.9 }}
                  animate={{ r: 38, opacity: 0 }}
                  transition={{ duration: 1.6, repeat: Infinity, ease: "easeOut" }}
                />
              )}
              <motion.circle
                cx={p.x}
                cy={p.y}
                animate={{ r: on ? 20 : 11, fill: on ? "#ffffff" : "rgba(255,255,255,0.12)" }}
                stroke="rgba(255,255,255,0.5)"
                strokeWidth="1"
                transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
              />
              <text
                x={p.x}
                y={p.y + 1}
                textAnchor="middle"
                dominantBaseline="middle"
                fontSize={on ? 13 : 0}
                fill="#000"
                className="font-display"
                style={{ transition: "font-size .4s" }}
              >
                {i + 1}
              </text>
            </g>
          );
        })}
      </svg>
    </div>
  );
}

export function Approach() {
  const { t, dir } = useLanguage();
  const idx = t.sectionIndex.findIndex((s) => s.id === "approach");
  const items = t.approach.items;
  const [active, setActive] = useState(0);
  const [paused, setPaused] = useState(false);
  const rtl = dir === "rtl";

  useEffect(() => {
    if (paused) return;
    const id = setTimeout(() => setActive((a) => (a + 1) % items.length), DURATION);
    return () => clearTimeout(id);
  }, [active, paused, items.length]);

  return (
    <section
      id="approach"
      className="relative flex min-h-screen flex-col justify-center overflow-hidden bg-black px-6 py-28 text-white isolate sm:px-10 lg:px-16"
    >
      <BlurShapes tone="dark" seed={1} />
      <div className="grain absolute inset-0 opacity-50" />

      <Reveal>
        <Kicker tone="light">{t.approach.kicker}</Kicker>
        <h2 className="mt-8 max-w-2xl font-display text-5xl font-semibold leading-tight tracking-tight sm:text-6xl">
          {t.approach.heading}
        </h2>
      </Reveal>

      <div
        className="relative z-10 mt-14 grid grid-cols-1 items-center gap-12 lg:grid-cols-[minmax(0,1.1fr)_minmax(0,0.9fr)] lg:gap-16"
        onMouseEnter={() => setPaused(true)}
        onMouseLeave={() => setPaused(false)}
      >
        <ul className="flex flex-col">
          {items.map((item, i) => {
            const on = i === active;
            return (
              <motion.li
                key={item.title}
                initial={{ opacity: 0, x: rtl ? 40 : -40 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true, amount: 0.4 }}
                transition={{ duration: 0.8, delay: i * 0.1, ease: [0.16, 1, 0.3, 1] }}
                className="relative border-t border-white/10 last:border-b"
              >
                <button
                  type="button"
                  onClick={() => setActive(i)}
                  className="group flex w-full items-start gap-5 py-5 text-start sm:gap-8 sm:py-6"
                  aria-expanded={on}
                >
                  <span
                    className="pt-2 font-display text-sm tabular-nums transition-colors duration-500"
                    style={{ color: on ? "#fff" : "rgba(255,255,255,0.3)" }}
                  >
                    {String(i + 1).padStart(2, "0")}
                  </span>
                  <span className="flex-1">
                    <span
                      className="block font-display text-2xl font-semibold tracking-tight transition-all duration-500 sm:text-4xl"
                      style={{ color: on ? "#fff" : "rgba(255,255,255,0.35)", transform: on ? `translateX(${rtl ? -8 : 8}px)` : "none" }}
                    >
                      {item.title}
                    </span>
                    <AnimatePresence initial={false}>
                      {on && (
                        <motion.span
                          key="copy"
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: "auto", opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
                          className="block overflow-hidden"
                        >
                          <span className="desc mt-3 block max-w-xl text-sm leading-relaxed text-white/65 sm:text-base">
                            {item.copy}
                          </span>
                        </motion.span>
                      )}
                    </AnimatePresence>
                  </span>
                </button>

                {/* progress line */}
                <span className="absolute inset-x-0 bottom-0 block h-px bg-transparent">
                  {on && (
                    <motion.span
                      key={`p-${active}-${paused}`}
                      className="block h-full bg-white"
                      style={{ transformOrigin: rtl ? "right" : "left" }}
                      initial={{ scaleX: 0 }}
                      animate={{ scaleX: paused ? 1 : 1 }}
                      transition={{ duration: paused ? 0.4 : DURATION / 1000, ease: "linear" }}
                    />
                  )}
                </span>
              </motion.li>
            );
          })}
        </ul>

        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 1.1, ease: [0.16, 1, 0.3, 1] }}
        >
          <PrincipleOrbit count={items.length} active={active} onPick={setActive} />
        </motion.div>
      </div>

      <PageMeta index={String(idx + 1).padStart(2, "0")} label={t.sectionIndex[idx].label} tone="light" />
    </section>
  );
}
