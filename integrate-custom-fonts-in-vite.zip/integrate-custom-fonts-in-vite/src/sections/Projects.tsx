"use client";

import { useMemo, useState } from "react";
import { BlurShapes } from "../components/BlurShapes";
import { motion } from "framer-motion";
import { Reveal } from "../components/Reveal";
import { Kicker, PageMeta } from "../components/ui";
import { WorkImage } from "../components/WorkImage";
import { useLanguage } from "../i18n/LanguageContext";
import { cn } from "../utils/cn";
import {
  WORK_URL,
  archiveWorks,
  groupLabels,
  works,
  type ArchiveWork,
  type Work,
  type WorkGroup,
} from "../data/projects";

const PAGE_SIZE = 12;
const ARCHIVE_PREVIEW = 12;

const copy = {
  ar: {
    all: "الكل",
    caseStudy: "دراسة الحالة",
    more: "عرض المزيد",
    remaining: "متبقي",
    allWork: "كل الأعمال على puiux.com",
    featured: "عمل مختار",
    archiveCount: "موقع آخر",
    total: "إجمالي الأعمال",
    archiveKicker: "الأرشيف",
    archiveTitle: "والمزيد من أعمالنا.",
    archiveSub: "44 موقعًا آخر صمّمناه وبنيناه لشركات وجهات في قطاعات مختلفة.",
    showAll: "عرض كل المواقع",
    showLess: "عرض أقل",
    filterLabel: "تصفية الأعمال",
    app: "تطبيق",
  },
  en: {
    all: "All",
    caseStudy: "Case study",
    more: "Show more",
    remaining: "left",
    allWork: "All work on puiux.com",
    featured: "Featured projects",
    archiveCount: "more sites",
    total: "Total projects",
    archiveKicker: "Archive",
    archiveTitle: "And more of our work.",
    archiveSub: "44 more sites we designed and built for companies and organisations across different sectors.",
    showAll: "Show all sites",
    showLess: "Show less",
    filterLabel: "Filter projects",
    app: "App",
  },
} as const;

const thumbOf = (cover: string) => cover.replace(/-c\.webp$/, "-t.webp");
const pad = (n: number) => String(n).padStart(2, "0");

function ArrowIcon({ rtl, className }: { rtl: boolean; className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className={className} aria-hidden>
      <path d={rtl ? "M21 12H3M10 5l-7 7 7 7" : "M3 12h18M14 5l7 7-7 7"} strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

/* ───────────────────────── Featured card ───────────────────────── */

function WorkCard({ w, index, i }: { w: Work; index: number; i: number }) {
  const { lang, dir } = useLanguage();
  const c = copy[lang];
  const rtl = dir === "rtl";
  const title = lang === "ar" ? w.titleAr : w.titleEn;
  const group = groupLabels[w.group][lang];

  return (
    <motion.li
      initial={{ opacity: 0, y: 28 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.15 }}
      transition={{ duration: 0.6, delay: (i % 3) * 0.07, ease: [0.16, 1, 0.3, 1] }}
      className="min-w-0"
    >
      <a href={w.caseUrl} target="_blank" rel="noreferrer" className="group flex h-full flex-col gap-5" aria-label={title}>
        <span
          className="relative block overflow-hidden rounded-xl bg-[#111] ring-1 ring-white/10 transition-all duration-700 ease-out group-hover:-translate-y-2 group-hover:ring-white/25"
          style={{ boxShadow: `0 40px 90px -55px ${w.accent}` }}
        >
          {w.phones ? (
            <span
              className="flex aspect-[1280/800] items-center justify-center gap-[2.4%] py-[5%]"
              style={{
                background: `radial-gradient(120% 90% at 50% 110%, ${w.accent}73, transparent 70%), #111`,
              }}
            >
              {w.phones.map((src, k) => (
                <span
                  key={src}
                  className="relative block h-full overflow-hidden rounded-[12px] bg-black ring-1 ring-white/15 shadow-[0_18px_40px_-18px_rgba(0,0,0,0.8)] transition-transform duration-700 ease-out"
                  style={{
                    aspectRatio: "390 / 845",
                    transitionDelay: `${k * 60}ms`,
                  }}
                >
                  <WorkImage
                    src={src}
                    alt={`${title} — ${c.app} ${k + 1}`}
                    fallbackLabel={title}
                    accent={w.accent}
                    imgClassName="group-hover:scale-[1.04]"
                  />
                </span>
              ))}
            </span>
          ) : (
            <>
              <span className="flex h-[30px] items-center gap-1.5 bg-[#161616] px-3" aria-hidden dir="ltr">
                <i className="h-2 w-2 rounded-full bg-[#3a3a3a]" />
                <i className="h-2 w-2 rounded-full bg-[#3a3a3a]" />
                <i className="h-2 w-2 rounded-full bg-[#3a3a3a]" />
                <em className="mx-auto max-w-[70%] truncate text-[11px] font-medium not-italic tracking-wide text-[#9a9a9a]">
                  {w.domain}
                </em>
              </span>
              <span className="block aspect-[1280/800]">
                <WorkImage
                  src={w.cover!}
                  srcSet={`${thumbOf(w.cover!)} 640w, ${w.cover} 1280w`}
                  sizes="(max-width:640px) 92vw, (max-width:1024px) 46vw, 30vw"
                  alt={w.alt ?? title}
                  fallbackLabel={title}
                  accent={w.accent}
                  imgClassName="group-hover:scale-[1.04]"
                />
              </span>
            </>
          )}
        </span>

        <span className="grid grid-cols-[auto_minmax(0,1fr)] items-baseline gap-x-4 gap-y-1">
          <span className="row-span-3 font-display text-[13px] tabular-nums text-white/35" dir="ltr">
            {pad(index + 1)}
          </span>
          <span className="flex flex-wrap items-center gap-x-3 text-[13px] text-white/50">
            <span>{lang === "ar" ? w.sectorAr : group}</span>
            {lang === "ar" && <span className="text-white/20">•</span>}
            {lang === "ar" && <span className="text-white/35">{group}</span>}
          </span>
          <h3 className="font-display text-xl font-semibold leading-snug tracking-tight text-white sm:text-[22px]">{title}</h3>
          {lang === "ar" ? (
            <p className="text-[14px] leading-relaxed text-white/55">{w.descAr}</p>
          ) : (
            <p className="text-[13px] text-white/45" dir="ltr">
              {w.domain ?? "iOS · Android"}
            </p>
          )}
          <span className="col-start-2 mt-2 inline-flex items-center gap-2 text-[13px] font-semibold text-white/80 transition group-hover:gap-3 group-hover:text-white">
            {c.caseStudy}
            <ArrowIcon rtl={rtl} className="h-4 w-4" />
          </span>
        </span>
      </a>
    </motion.li>
  );
}

/* ───────────────────────── Archive card ───────────────────────── */

function ArchiveCard({ a, i }: { a: ArchiveWork; i: number }) {
  const { lang } = useLanguage();
  const title = lang === "ar" ? a.titleAr : a.titleEn;
  return (
    <motion.li
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.15 }}
      transition={{ duration: 0.5, delay: (i % 4) * 0.06, ease: [0.16, 1, 0.3, 1] }}
      className="group min-w-0"
    >
      <div className="overflow-hidden rounded-lg bg-[#111] ring-1 ring-white/10 transition-all duration-500 group-hover:-translate-y-1 group-hover:ring-white/25">
        <div className="aspect-[640/400]">
          <WorkImage
            src={a.cover}
            alt={title}
            fallbackLabel={title}
            imgClassName="group-hover:scale-[1.05]"
          />
        </div>
      </div>
      <div className="mt-3 flex flex-col gap-0.5">
        <h4 className="font-display text-[15px] font-semibold leading-snug text-white/90">{title}</h4>
        <span className="text-[12px] text-white/45">{lang === "ar" ? a.sectorAr : a.sectorEn}</span>
      </div>
    </motion.li>
  );
}

/* ───────────────────────── Section ───────────────────────── */

export function Projects() {
  const { t, dir, lang } = useLanguage();
  const c = copy[lang];
  const rtl = dir === "rtl";
  const idx = t.sectionIndex.findIndex((s) => s.id === "projects");

  const [filter, setFilter] = useState<WorkGroup | "all">("all");
  const [limit, setLimit] = useState(PAGE_SIZE);
  const [archiveOpen, setArchiveOpen] = useState(false);

  const groups = useMemo(() => {
    const counts = new Map<WorkGroup, number>();
    works.forEach((w) => counts.set(w.group, (counts.get(w.group) ?? 0) + 1));
    return (Object.keys(groupLabels) as WorkGroup[]).filter((g) => counts.has(g)).map((g) => ({ g, n: counts.get(g)! }));
  }, []);

  const filtered = useMemo(
    () =>
      works
        .map((w, index) => ({ w, index }))
        .filter(({ w }) => filter === "all" || w.group === filter),
    [filter]
  );
  const visible = filtered.slice(0, limit);
  const remaining = filtered.length - visible.length;
  const archiveVisible = archiveOpen ? archiveWorks : archiveWorks.slice(0, ARCHIVE_PREVIEW);

  const pick = (g: WorkGroup | "all") => {
    setFilter(g);
    setLimit(PAGE_SIZE);
  };

  return (
    <section id="projects" className="relative bg-black px-6 py-28 text-white sm:px-10 lg:px-16 isolate">
      <BlurShapes tone="dark" seed={13} />
      {/* header */}
      <Reveal className="flex flex-col items-start justify-between gap-12 lg:flex-row lg:items-center lg:gap-16">
        <div className="min-w-0">
          <Kicker tone="light">{t.projects.kicker}</Kicker>
          <h2 className="mt-8 max-w-2xl font-display text-5xl font-semibold leading-tight tracking-tight sm:text-6xl">
            {t.projects.heading}
          </h2>
          <p className="mt-6 max-w-2xl text-sm leading-relaxed text-white/60 sm:text-base">{t.projects.subheading}</p>

          {/* stats */}
          <div className="mt-10 grid max-w-3xl grid-cols-3 gap-px overflow-hidden rounded-xl bg-white/10 ring-1 ring-white/10">
            {[
              { n: works.length + archiveWorks.length, l: c.total },
              { n: works.length, l: c.featured },
              { n: archiveWorks.length, l: c.archiveCount },
            ].map((s) => (
              <div key={s.l} className="bg-black px-5 py-5">
                <div className="font-display text-3xl font-semibold tabular-nums sm:text-4xl" dir="ltr">
                  {s.n}
                </div>
                <div className="mt-1 text-[12px] text-white/50">{s.l}</div>
              </div>
            ))}
          </div>
        </div>

        {/* all-work circle */}
        <a
          href={WORK_URL}
          target="_blank"
          rel="noreferrer"
          aria-label={c.allWork}
          className="group relative mx-auto flex h-48 w-48 shrink-0 items-center justify-center sm:h-56 sm:w-56 lg:mx-0 lg:h-64 lg:w-64"
        >
          <span
            aria-hidden
            className="absolute inset-0 rounded-full border border-white/20 transition-all duration-500 group-hover:scale-[1.04] group-hover:border-white group-hover:bg-white"
          />
          <motion.span
            aria-hidden
            className="absolute -inset-3 rounded-full border border-dashed border-white/10"
            animate={{ rotate: 360 }}
            transition={{ duration: 40, repeat: Infinity, ease: "linear" }}
          />
          <span className="relative flex flex-col items-center gap-4 px-8 text-center text-white transition-colors duration-500 group-hover:text-black">
            <span className="text-sm font-semibold leading-snug sm:text-base">{c.allWork}</span>
            <span className="flex h-11 w-11 items-center justify-center rounded-full border border-current transition-transform duration-500 group-hover:rotate-45 rtl:group-hover:-rotate-45">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" className="h-5 w-5" aria-hidden>
                <path d={rtl ? "M17 7L7 17M7 8v9h9" : "M7 17L17 7M8 7h9v9"} strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </span>
          </span>
        </a>
      </Reveal>

      {/* filters */}
      <Reveal delay={120} className="mt-12">
        <div role="group" aria-label={c.filterLabel} className="flex flex-wrap gap-2.5">
          {[{ g: "all" as const, n: works.length }, ...groups].map(({ g, n }) => {
            const on = filter === g;
            return (
              <button
                key={g}
                type="button"
                onClick={() => pick(g)}
                aria-pressed={on}
                className={cn(
                  "inline-flex items-center gap-2 rounded-full border px-4 py-2 text-[13px] font-medium transition",
                  on
                    ? "border-white bg-white text-black"
                    : "border-white/15 text-white/65 hover:border-white/40 hover:text-white"
                )}
              >
                {g === "all" ? c.all : groupLabels[g][lang]}
                <span className={cn("text-[11px] tabular-nums", on ? "text-black/50" : "text-white/35")}>{n}</span>
              </button>
            );
          })}
        </div>
      </Reveal>

      {/* featured grid */}
      <ul className="mt-12 grid grid-cols-1 gap-x-7 gap-y-14 md:grid-cols-2 lg:grid-cols-3">
        {visible.map(({ w, index }, i) => (
          <WorkCard key={w.slug} w={w} index={index} i={i} />
        ))}
      </ul>

      {remaining > 0 && (
        <div className="mt-16 flex justify-center">
          <button
            type="button"
            onClick={() => setLimit((l) => l + PAGE_SIZE)}
            className="group inline-flex items-center gap-3 rounded-full border border-white/20 px-7 py-3.5 text-xs font-semibold uppercase tracking-[0.2em] text-white transition hover:border-white hover:bg-white hover:text-black"
          >
            {c.more}
            <span className="text-[11px] tabular-nums text-white/45 group-hover:text-black/55">
              {remaining} {c.remaining}
            </span>
          </button>
        </div>
      )}

      {/* archive */}
      <div className="relative mt-28 border-t border-white/10 pt-20">
        <Reveal className="flex flex-wrap items-end justify-between gap-6">
          <div>
            <Kicker tone="light">{c.archiveKicker}</Kicker>
            <h3 className="mt-6 font-display text-4xl font-semibold tracking-tight sm:text-5xl">{c.archiveTitle}</h3>
            <p className="mt-4 max-w-xl text-sm leading-relaxed text-white/55 sm:text-base">{c.archiveSub}</p>
          </div>
        </Reveal>

        <ul className="mt-12 grid grid-cols-2 gap-x-5 gap-y-9 md:grid-cols-3 lg:grid-cols-4">
          {archiveVisible.map((a, i) => (
            <ArchiveCard key={a.titleEn} a={a} i={i} />
          ))}
        </ul>

        <div className="mt-14 flex justify-center">
          <button
            type="button"
            onClick={() => setArchiveOpen((o) => !o)}
            className="rounded-full border border-white/20 px-7 py-3.5 text-xs font-semibold uppercase tracking-[0.2em] text-white transition hover:border-white hover:bg-white hover:text-black"
          >
            {archiveOpen ? c.showLess : `${c.showAll} (${archiveWorks.length})`}
          </button>
        </div>
      </div>

      <PageMeta index={pad(idx + 1)} label={t.sectionIndex[idx].label} tone="light" />
    </section>
  );
}
